# Fat-Free-PHP-MVC-Sample-Project

This a sample project to kick-start an MVC web application based on the Fat-Free PHP Framework. 

The project is a result of a tutorial series that you can follow on http://takacsmark.com. 

The sample project works with a MySQL database. After cloning the repository update database configuration info in the config.ini file. 

You can run the project from the project directory by issuing the command "php -S localhost:8088 -t .".

If you prefer to use your own web server, please make sure that it is configured to support f3 routing as described on http://fatfreeframework.com/routing-engine.
